# JARVIS for Android — first native build

A first native Android implementation inspired by OpenJarvis's architecture. This is **not** a direct APK conversion of OpenJarvis. OpenJarvis itself is a Python/Rust local-first AI framework with desktop tooling; this app is a separate Kotlin/Jetpack Compose client that uses Claude's Messages API for cloud inference and stores user-approved notes, tasks, and chat history locally.

## Included in this version

- Native Android app UI (Kotlin + Jetpack Compose)
- Claude Messages API chat (`claude-sonnet-5` by default; model ID is editable)
- API key encrypted at rest using Android Keystore AES-GCM
- Android speech recognition intent for voice input (device speech service/language support required)
- Android TextToSpeech for optional spoken replies
- Local SQLite storage for chat history, tasks, and user-approved memories
- Saved memories and open tasks are added to the system context sent with a chat request
- GitHub Actions workflow to build a debug APK without installing Android Studio on the phone

## Not included yet

Telegram bot integration, autonomous background agents, notifications/reminders, streaming responses, local on-device LLM inference, and app-level control of phone settings are not implemented in this first version. They need separate permission, lifecycle, reliability, and security work. The app does not silently run commands on the device.

## Requirements

- Android Studio with Android SDK Platform 36, or GitHub Actions (workflow included)
- JDK 17 or 21 (CI uses JDK 21)
- Android device: Android 8.0/API 26 or later. Built for current Android devices, including Android 15.

## Build in Android Studio

1. Extract this project ZIP.
2. In Android Studio select **Open** and choose the `JARVIS-Android` folder (the folder containing `settings.gradle.kts`).
3. Let Gradle sync and install any requested Android SDK 36 platform/build tools.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. The debug APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer that APK to the phone and install it. Android may ask permission to install from that file manager/browser.

## Build APK through GitHub Actions (no Android Studio on the phone)

1. Create a new empty GitHub repository.
2. Upload the *contents* of this project folder to the repository root (do not upload the parent ZIP as a single file).
3. Open the repository's **Actions** tab and enable workflows if GitHub asks.
4. Run **Build JARVIS APK** using **Run workflow**, or push to the `main` branch.
5. Open the completed workflow run and download the `jarvis-debug-apk` artifact. GitHub downloads it as a ZIP; extract `app-debug.apk` and install it on Android.

## Connect Claude

1. Check Anthropic's current age and API-use terms before enabling the connection. Anthropic's consumer Claude service is 18+; applications built with its API for minors have additional safeguards and compliance requirements. Do not misstate age or use another person's account without their explicit supervision. A parent/guardian or school should arrange and oversee any permitted API access for a minor.
2. An ordinary Claude chat subscription does not automatically provide API credits. An eligible API account must have billing/credits configured.
3. Install/open JARVIS, go to **Sozlama**, and paste the permitted API key.
4. Save the key. The app encrypts it with a key held in Android Keystore; it is not written in plaintext to the app preferences.
5. Confirm the model ID is available to the API account. The default in this project is `claude-sonnet-5`; you can edit it in Settings.
6. Send a test message in Chat.

**Cost warning:** Claude API requests may incur usage charges under the Anthropic API account. Set usage limits in Anthropic Console before regular use. Anthropic policy references: https://www.anthropic.com/transparency/voluntary-commitments and https://www.anthropic.com/policy.

## Privacy and security notes

- Chat history, tasks, and notes are stored in the app's private local SQLite database.
- When sending a prompt, the app sends the latest conversation history (up to 30 messages), saved notes (up to 30) and open tasks (up to 30) to Anthropic so Claude can use that context. Do not store passwords, payment card details, private keys, or other secrets in Memory.
- The API key is encrypted at rest with Android Keystore AES-GCM. No mobile app can fully hide a user-supplied API key from a sufficiently privileged or compromised device; for public distribution, a trusted backend proxy is safer than embedding end-user API credentials in every app installation.
- API calls require an internet connection. The local task list and notes remain available offline.
- Voice input uses the Android speech recognition service; its availability and Uzbek language support depend on the device's installed speech services. Depending on the speech provider, voice recognition may send audio to that provider and may require internet; review that provider's privacy policy. TextToSpeech voice quality and Uzbek voice availability depend on installed Android voices.

## OpenJarvis reference

OpenJarvis: https://github.com/open-jarvis/OpenJarvis

The upstream README describes a Python 3.11+ project with Rust extensions and desktop installers. This Android app reuses architectural ideas (agent-oriented interaction, local memory, and modular tools) rather than importing or packaging the upstream Python/Rust runtime. Upstream project license: Apache-2.0.
