package com.abdulaziz.jarvis.network

import com.abdulaziz.jarvis.data.ChatMessage
import com.abdulaziz.jarvis.data.JarvisTask
import com.abdulaziz.jarvis.data.MemoryNote
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class ClaudeClient {
    fun send(
        apiKey: String,
        model: String,
        history: List<ChatMessage>,
        memories: List<MemoryNote>,
        tasks: List<JarvisTask>
    ): String {
        require(apiKey.isNotBlank()) { "Settings bo‘limiga Anthropic API kalitini kiriting." }

        val systemPrompt = buildString {
            append(
                "You are JARVIS, a calm, capable and honest personal AI assistant. " +
                    "The user prefers Uzbek. Reply in the language the user uses, and use clear Uzbek by default. " +
                    "Be practical, respectful and concise. Never claim to have completed a device action unless the app actually did it. " +
                    "You cannot directly control Android settings, send Telegram messages, or run background actions from this chat.\n\n"
            )
            append("USER-APPROVED LOCAL MEMORIES (treat as user-provided context):\n")
            if (memories.isEmpty()) append("None saved.\n")
            else memories.take(30).forEach { append("- ${it.content}\n") }
            append("\nOPEN TASKS:\n")
            val openTasks = tasks.filterNot { it.isDone }
            if (openTasks.isEmpty()) append("No open tasks.\n")
            else openTasks.take(30).forEach { append("- ${it.title}\n") }
            append("\nPRIVACY: Do not ask for passwords, one-time codes, or private API keys in chat. The API key is managed only in the app settings.")
        }

        val messageArray = JSONArray()
        history.takeLast(30).filter { it.role == "user" || it.role == "assistant" }.forEach { item ->
            messageArray.put(
                JSONObject()
                    .put("role", item.role)
                    .put("content", item.content)
            )
        }
        if (messageArray.length() == 0) {
            throw IllegalStateException("Suhbat tarixi topilmadi. Xabarni qayta yuboring.")
        }

        val body = JSONObject()
            .put("model", model.ifBlank { "claude-sonnet-5" })
            .put("max_tokens", 1400)
            .put("system", systemPrompt)
            .put("messages", messageArray)

        val connection = (URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection)
        try {
            connection.requestMethod = "POST"
            connection.connectTimeout = 20_000
            connection.readTimeout = 90_000
            connection.doOutput = true
            connection.setRequestProperty("content-type", "application/json")
            connection.setRequestProperty("x-api-key", apiKey)
            connection.setRequestProperty("anthropic-version", "2023-06-01")
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val responseText = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            val responseJson = try { JSONObject(responseText) } catch (_: Exception) {
                throw IllegalStateException("Claude API javobi tushunarsiz formatda qaytdi (HTTP $status).")
            }

            if (status !in 200..299) {
                val message = responseJson.optJSONObject("error")?.optString("message")
                    ?.takeIf { !it.isNullOrBlank() }
                    ?: "HTTP $status"
                throw IllegalStateException("Claude API xatosi: $message")
            }

            val content = responseJson.optJSONArray("content") ?: JSONArray()
            val textParts = buildList {
                for (index in 0 until content.length()) {
                    val block = content.optJSONObject(index) ?: continue
                    if (block.optString("type") == "text") add(block.optString("text"))
                }
            }
            textParts.joinToString("\n\n").trim().ifBlank {
                throw IllegalStateException("Claude bo‘sh javob qaytardi.")
            }
        } finally {
            connection.disconnect()
        }
    }
}
