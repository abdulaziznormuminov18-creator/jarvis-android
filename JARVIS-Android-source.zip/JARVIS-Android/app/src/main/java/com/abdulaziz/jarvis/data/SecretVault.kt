package com.abdulaziz.jarvis.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Encrypts the user's API key at rest with an Android Keystore AES-GCM key. */
class SecretVault(context: Context) {
    private val prefs = context.getSharedPreferences("jarvis_secure_settings", Context.MODE_PRIVATE)
    private val alias = "jarvis_anthropic_key_v1"

    fun saveApiKey(apiKey: String) {
        require(apiKey.isNotBlank()) { "API key cannot be empty." }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val ciphertext = cipher.doFinal(apiKey.trim().toByteArray(Charsets.UTF_8))
        val combined = cipher.iv + ciphertext
        prefs.edit().putString("anthropic_key_enc", Base64.encodeToString(combined, Base64.NO_WRAP)).apply()
    }

    fun readApiKey(): String? {
        val encoded = prefs.getString("anthropic_key_enc", null) ?: return null
        return try {
            val combined = Base64.decode(encoded, Base64.NO_WRAP)
            if (combined.size <= 12) return null
            val iv = combined.copyOfRange(0, 12)
            val ciphertext = combined.copyOfRange(12, combined.size)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(ciphertext), Charsets.UTF_8)
        } catch (_: Exception) {
            null
        }
    }

    fun clearApiKey() {
        prefs.edit().remove("anthropic_key_enc").apply()
    }

    fun getModel(): String = prefs.getString("model_name", "claude-sonnet-5") ?: "claude-sonnet-5"

    fun saveModel(model: String) {
        prefs.edit().putString("model_name", model.trim().ifBlank { "claude-sonnet-5" }).apply()
    }

    fun isVoiceReplyEnabled(): Boolean = prefs.getBoolean("voice_reply", false)

    fun setVoiceReplyEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("voice_reply", enabled).apply()
    }

    private fun getOrCreateKey(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (keyStore.getKey(alias, null) as? SecretKey)?.let { return it }

        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        val spec = KeyGenParameterSpec.Builder(
            alias,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true)
            .build()
        generator.init(spec)
        return generator.generateKey()
    }
}
