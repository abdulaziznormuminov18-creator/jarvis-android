package com.abdulaziz.jarvis.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** Local-only persistence for conversation history, tasks and user-approved memories. */
class LocalDatabase(context: Context) : SQLiteOpenHelper(context, "jarvis_local.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                role TEXT NOT NULL,
                content TEXT NOT NULL,
                created_at INTEGER NOT NULL
            )""".trimIndent()
        )
        db.execSQL(
            """CREATE TABLE tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                is_done INTEGER NOT NULL DEFAULT 0,
                created_at INTEGER NOT NULL
            )""".trimIndent()
        )
        db.execSQL(
            """CREATE TABLE memories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                content TEXT NOT NULL,
                created_at INTEGER NOT NULL
            )""".trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Keep user data. Future schema changes must use explicit migrations.
    }

    @Synchronized
    fun addMessage(role: String, content: String): Long {
        val values = ContentValues().apply {
            put("role", role)
            put("content", content)
            put("created_at", System.currentTimeMillis())
        }
        return writableDatabase.insert("messages", null, values)
    }

    @Synchronized
    fun getMessages(limit: Int = 80): List<ChatMessage> {
        val result = mutableListOf<ChatMessage>()
        readableDatabase.rawQuery(
            "SELECT id, role, content, created_at FROM messages ORDER BY id DESC LIMIT ?",
            arrayOf(limit.coerceIn(1, 300).toString())
        ).use { cursor ->
            while (cursor.moveToNext()) {
                result += ChatMessage(
                    id = cursor.getLong(0),
                    role = cursor.getString(1),
                    content = cursor.getString(2),
                    createdAt = cursor.getLong(3)
                )
            }
        }
        return result.asReversed()
    }

    @Synchronized
    fun clearMessages() {
        writableDatabase.delete("messages", null, null)
    }

    @Synchronized
    fun addTask(title: String): Long {
        val values = ContentValues().apply {
            put("title", title)
            put("is_done", 0)
            put("created_at", System.currentTimeMillis())
        }
        return writableDatabase.insert("tasks", null, values)
    }

    @Synchronized
    fun getTasks(): List<JarvisTask> {
        val result = mutableListOf<JarvisTask>()
        readableDatabase.rawQuery(
            "SELECT id, title, is_done, created_at FROM tasks ORDER BY is_done ASC, id DESC",
            null
        ).use { cursor ->
            while (cursor.moveToNext()) {
                result += JarvisTask(
                    id = cursor.getLong(0),
                    title = cursor.getString(1),
                    isDone = cursor.getInt(2) == 1,
                    createdAt = cursor.getLong(3)
                )
            }
        }
        return result
    }

    @Synchronized
    fun setTaskDone(id: Long, done: Boolean) {
        val values = ContentValues().apply { put("is_done", if (done) 1 else 0) }
        writableDatabase.update("tasks", values, "id = ?", arrayOf(id.toString()))
    }

    @Synchronized
    fun deleteTask(id: Long) {
        writableDatabase.delete("tasks", "id = ?", arrayOf(id.toString()))
    }

    @Synchronized
    fun addMemory(content: String): Long {
        val values = ContentValues().apply {
            put("content", content)
            put("created_at", System.currentTimeMillis())
        }
        return writableDatabase.insert("memories", null, values)
    }

    @Synchronized
    fun getMemories(): List<MemoryNote> {
        val result = mutableListOf<MemoryNote>()
        readableDatabase.rawQuery(
            "SELECT id, content, created_at FROM memories ORDER BY id DESC", null
        ).use { cursor ->
            while (cursor.moveToNext()) {
                result += MemoryNote(
                    id = cursor.getLong(0),
                    content = cursor.getString(1),
                    createdAt = cursor.getLong(2)
                )
            }
        }
        return result
    }

    @Synchronized
    fun deleteMemory(id: Long) {
        writableDatabase.delete("memories", "id = ?", arrayOf(id.toString()))
    }
}

data class ChatMessage(val id: Long, val role: String, val content: String, val createdAt: Long)
data class JarvisTask(val id: Long, val title: String, val isDone: Boolean, val createdAt: Long)
data class MemoryNote(val id: Long, val content: String, val createdAt: Long)
