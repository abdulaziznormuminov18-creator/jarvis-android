package com.abdulaziz.jarvis

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.abdulaziz.jarvis.data.ChatMessage
import com.abdulaziz.jarvis.data.JarvisTask
import com.abdulaziz.jarvis.data.LocalDatabase
import com.abdulaziz.jarvis.data.MemoryNote
import com.abdulaziz.jarvis.data.SecretVault
import com.abdulaziz.jarvis.network.ClaudeClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import java.util.concurrent.atomic.AtomicReference

private val AppBackground = Color(0xFF080F1C)
private val Panel = Color(0xFF111C2D)
private val PanelRaised = Color(0xFF17263B)
private val Accent = Color(0xFF55C7F5)
private val AccentSoft = Color(0xFF183D55)
private val MainText = Color(0xFFEAF4FF)
private val MutedText = Color(0xFF91A5BB)
private val UserBubble = Color(0xFF173A55)
private val ErrorColor = Color(0xFFFFA59B)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(8, 15, 28)
        window.navigationBarColor = android.graphics.Color.rgb(8, 15, 28)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Accent,
                    onPrimary = AppBackground,
                    secondary = Accent,
                    background = AppBackground,
                    surface = Panel,
                    surfaceVariant = PanelRaised,
                    onBackground = MainText,
                    onSurface = MainText,
                    outline = Color(0xFF36516A)
                )
            ) {
                JarvisHome()
            }
        }
    }
}

private enum class AppTab(val label: String, val symbol: String) {
    CHAT("Chat", "◉"), TASKS("Vazifalar", "✓"), MEMORY("Xotira", "⌘"), SETTINGS("Sozlama", "⚙")
}

@Composable
private fun JarvisHome() {
    val context = LocalContext.current
    val database = remember { LocalDatabase(context.applicationContext) }
    val vault = remember { SecretVault(context.applicationContext) }
    val scope = rememberCoroutineScope()

    var selectedTab by remember { mutableStateOf(AppTab.CHAT) }
    var messages by remember { mutableStateOf<List<ChatMessage>>(emptyList()) }
    var tasks by remember { mutableStateOf<List<JarvisTask>>(emptyList()) }
    var memories by remember { mutableStateOf<List<MemoryNote>>(emptyList()) }
    var input by remember { mutableStateOf("") }
    var isBusy by remember { mutableStateOf(false) }
    var errorText by remember { mutableStateOf<String?>(null) }
    var feedbackIsError by remember { mutableStateOf(true) }
    var apiKeyIsSaved by remember { mutableStateOf(vault.readApiKey() != null) }
    var modelName by remember { mutableStateOf(vault.getModel()) }
    var voiceReplyEnabled by remember { mutableStateOf(vault.isVoiceReplyEnabled()) }

    val ttsReference = remember { AtomicReference<TextToSpeech?>(null) }
    val textToSpeech = remember(context) {
        TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReference.get()?.let { engine ->
                    val uzbek = Locale.forLanguageTag("uz-UZ")
                    val result = engine.setLanguage(uzbek)
                    if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                        engine.language = Locale.getDefault()
                    }
                }
            }
        }.also { ttsReference.set(it) }
    }
    DisposableEffect(textToSpeech) {
        onDispose {
            textToSpeech.stop()
            textToSpeech.shutdown()
        }
    }

    fun reloadLocalData() {
        scope.launch {
            val loaded = withContext(Dispatchers.IO) {
                Triple(database.getMessages(), database.getTasks(), database.getMemories())
            }
            messages = loaded.first
            tasks = loaded.second
            memories = loaded.third
        }
    }

    LaunchedEffect(Unit) { reloadLocalData() }

    val speechResultLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) input = spoken
    }
    val microphonePermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "uz-UZ")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "JARVIS uchun gapiring")
            }
            try {
                speechResultLauncher.launch(intent)
            } catch (_: Exception) {
                feedbackIsError = true
                errorText = "Bu telefonda ovozli tanish xizmati mavjud emas."
            }
        } else {
            feedbackIsError = true
            errorText = "Ovozli buyruq uchun mikrofon ruxsati kerak."
        }
    }

    fun startVoiceInput() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "uz-UZ")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "JARVIS uchun gapiring")
            }
            try {
                speechResultLauncher.launch(intent)
            } catch (_: Exception) {
                feedbackIsError = true
                errorText = "Bu telefonda ovozli tanish xizmati mavjud emas."
            }
        } else {
            microphonePermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    fun sendCurrentMessage() {
        val prompt = input.trim()
        if (prompt.isEmpty() || isBusy) return
        if (vault.readApiKey().isNullOrBlank()) {
            selectedTab = AppTab.SETTINGS
            feedbackIsError = true
            errorText = "Avval Sozlama bo‘limida Anthropic API kalitini saqlang."
            return
        }
        input = ""
        errorText = null
        isBusy = true
        scope.launch {
            try {
                val currentHistory = withContext(Dispatchers.IO) {
                    database.addMessage("user", prompt)
                    database.getMessages(80)
                }
                messages = currentHistory

                val answer = withContext(Dispatchers.IO) {
                    ClaudeClient().send(
                        apiKey = vault.readApiKey().orEmpty(),
                        model = vault.getModel(),
                        history = currentHistory,
                        memories = database.getMemories(),
                        tasks = database.getTasks()
                    )
                }
                messages = withContext(Dispatchers.IO) {
                    database.addMessage("assistant", answer)
                    database.getMessages(80)
                }
                if (voiceReplyEnabled) {
                    textToSpeech.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
                }
            } catch (exception: Exception) {
                // The user's message is already stored; surface the API error separately.
                feedbackIsError = true
                errorText = exception.message ?: "Noma'lum xatolik yuz berdi."
                messages = withContext(Dispatchers.IO) { database.getMessages(80) }
            } finally {
                isBusy = false
            }
        }
    }

    Scaffold(
        containerColor = AppBackground,
        contentWindowInsets = WindowInsets.safeDrawing,
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF0D1726)) {
                AppTab.entries.forEach { tab ->
                    NavigationBarItem(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab; errorText = null },
                        icon = { Text(tab.symbol, fontSize = 20.sp, fontWeight = FontWeight.Bold) },
                        label = { Text(tab.label, fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Accent,
                            selectedTextColor = Accent,
                            indicatorColor = AccentSoft,
                            unselectedIconColor = MutedText,
                            unselectedTextColor = MutedText
                        )
                    )
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(AppBackground)
        ) {
            Header(isConnected = apiKeyIsSaved, modelName = modelName)
            errorText?.let { message ->
                Card(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp),
                    colors = CardDefaults.cardColors(containerColor = if (feedbackIsError) Color(0xFF3A2428) else Color(0xFF17372F))
                ) {
                    Text(message, color = if (feedbackIsError) ErrorColor else Color(0xFF8CE2B7), modifier = Modifier.padding(12.dp), fontSize = 13.sp)
                }
            }
            when (selectedTab) {
                AppTab.CHAT -> ChatPane(
                    messages = messages,
                    input = input,
                    onInputChange = { input = it },
                    isBusy = isBusy,
                    onSend = { sendCurrentMessage() },
                    onVoice = { startVoiceInput() },
                    onOpenSettings = { selectedTab = AppTab.SETTINGS }
                )
                AppTab.TASKS -> TasksPane(
                    tasks = tasks,
                    onAdd = { title ->
                        scope.launch {
                            tasks = withContext(Dispatchers.IO) {
                                database.addTask(title)
                                database.getTasks()
                            }
                        }
                    },
                    onToggle = { task, done ->
                        scope.launch {
                            tasks = withContext(Dispatchers.IO) {
                                database.setTaskDone(task.id, done)
                                database.getTasks()
                            }
                        }
                    },
                    onDelete = { task ->
                        scope.launch {
                            tasks = withContext(Dispatchers.IO) {
                                database.deleteTask(task.id)
                                database.getTasks()
                            }
                        }
                    }
                )
                AppTab.MEMORY -> MemoryPane(
                    memories = memories,
                    onAdd = { note ->
                        scope.launch {
                            memories = withContext(Dispatchers.IO) {
                                database.addMemory(note)
                                database.getMemories()
                            }
                        }
                    },
                    onDelete = { note ->
                        scope.launch {
                            memories = withContext(Dispatchers.IO) {
                                database.deleteMemory(note.id)
                                database.getMemories()
                            }
                        }
                    }
                )
                AppTab.SETTINGS -> SettingsPane(
                    vault = vault,
                    saved = apiKeyIsSaved,
                    currentModel = modelName,
                    voiceReplyEnabled = voiceReplyEnabled,
                    onSaveKey = { key ->
                        try {
                            vault.saveApiKey(key)
                            apiKeyIsSaved = true
                            feedbackIsError = false
                            errorText = "API kalit qurilmada shifrlangan holda saqlandi."
                        } catch (exception: Exception) {
                            feedbackIsError = true
                            errorText = exception.message ?: "API kalitni saqlab bo‘lmadi."
                        }
                    },
                    onDeleteKey = {
                        vault.clearApiKey()
                        apiKeyIsSaved = false
                        feedbackIsError = false
                        errorText = "API kalit o‘chirildi."
                    },
                    onModelChange = { modelName = it.trim().ifBlank { "claude-sonnet-5" }; vault.saveModel(modelName) },
                    onVoiceReplyChange = { voiceReplyEnabled = it; vault.setVoiceReplyEnabled(it) }
                )
            }
        }
    }
}

@Composable
private fun Header(isConnected: Boolean, modelName: String) {
    Row(
        modifier = Modifier.fillMaxWidth().background(Color(0xFF0B1524)).padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier.size(42.dp).clip(CircleShape).background(AccentSoft),
            contentAlignment = Alignment.Center
        ) {
            Text("J", color = Accent, fontWeight = FontWeight.ExtraBold, fontSize = 23.sp)
        }
        Spacer(Modifier.width(11.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text("J.A.R.V.I.S", color = MainText, fontSize = 18.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Text("PERSONAL AI COMPANION", color = MutedText, fontSize = 9.sp, letterSpacing = 1.5.sp)
        }
        Column(horizontalAlignment = Alignment.End) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(7.dp).clip(CircleShape).background(if (isConnected) Color(0xFF5CDAA6) else Color(0xFFFFB86B)))
                Spacer(Modifier.width(5.dp))
                Text(if (isConnected) "KEY SAVED" else "SETUP REQUIRED", color = if (isConnected) Color(0xFF75DDB0) else Color(0xFFFFC27D), fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
            Text(modelName, color = MutedText, fontSize = 9.sp)
        }
    }
}

@Composable
private fun ChatPane(
    messages: List<ChatMessage>,
    input: String,
    onInputChange: (String) -> Unit,
    isBusy: Boolean,
    onSend: () -> Unit,
    onVoice: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val listState = rememberLazyListState()
    LaunchedEffect(messages.size, isBusy) {
        val lastVisibleIndex = messages.size + if (isBusy) 1 else 0
        if (messages.isNotEmpty() || isBusy) listState.animateScrollToItem(lastVisibleIndex)
    }

    Column(modifier = Modifier.fillMaxSize().imePadding()) {
        if (messages.isEmpty()) {
            Column(
                modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(Modifier.size(104.dp).clip(CircleShape).background(PanelRaised), contentAlignment = Alignment.Center) {
                    Text("J", color = Accent, fontSize = 54.sp, fontWeight = FontWeight.Light)
                }
                Spacer(Modifier.height(20.dp))
                Text("Xush kelibsiz.", color = MainText, fontSize = 25.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(7.dp))
                Text(
                    "Men JARVIS. Rejalaringizni tartibga solish, savollarga javob berish va kundalik ishlaringizda yordam berish uchun shu yerdaman.",
                    color = MutedText,
                    fontSize = 14.sp,
                    lineHeight = 21.sp
                )
                Spacer(Modifier.height(18.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
                    Column(Modifier.padding(14.dp)) {
                        Text("BOSHLASH UCHUN", color = Accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                        Spacer(Modifier.height(7.dp))
                        Text("• Bugungi rejamni tuzishga yordam ber.\n• Ingliz tilini o‘rganish uchun 30 daqiqalik reja tuz.\n• Mening ustuvor vazifalarimni sarala.", color = MainText, fontSize = 13.sp, lineHeight = 20.sp)
                    }
                }
                Spacer(Modifier.height(14.dp))
                TextButton(onClick = onOpenSettings) { Text("API kalitini sozlash", color = Accent) }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 13.dp),
                state = listState,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item { Spacer(Modifier.height(4.dp)) }
                items(messages, key = { it.id }) { message -> MessageBubble(message) }
                if (isBusy) item { ThinkingBubble() }
                item { Spacer(Modifier.height(8.dp)) }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth().background(Color(0xFF0D1726)).padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            OutlinedButton(
                onClick = onVoice,
                modifier = Modifier.height(54.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Accent)
            ) { Text("MIC", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
            Spacer(Modifier.width(8.dp))
            OutlinedTextField(
                value = input,
                onValueChange = onInputChange,
                modifier = Modifier.weight(1f),
                placeholder = { Text("JARVIS'ga xabar yozing…", color = MutedText, fontSize = 13.sp) },
                maxLines = 4,
                shape = RoundedCornerShape(17.dp)
            )
            Spacer(Modifier.width(7.dp))
            Button(
                onClick = onSend,
                enabled = !isBusy && input.isNotBlank(),
                modifier = Modifier.height(54.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = AppBackground)
            ) { Text(if (isBusy) "…" else "SEND", fontSize = 10.sp, fontWeight = FontWeight.ExtraBold) }
        }
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    val isUser = message.role == "user"
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        Text(if (isUser) "YOU" else "JARVIS", color = MutedText, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp, modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp))
        Card(
            modifier = Modifier.fillMaxWidth(0.92f),
            shape = RoundedCornerShape(if (isUser) 18.dp else 18.dp),
            colors = CardDefaults.cardColors(containerColor = if (isUser) UserBubble else Panel)
        ) {
            Text(message.content, color = MainText, fontSize = 14.sp, lineHeight = 21.sp, modifier = Modifier.padding(14.dp))
        }
    }
}

@Composable
private fun ThinkingBubble() {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Text("JARVIS javob tayyorlamoqda…", color = Accent, fontSize = 13.sp, modifier = Modifier.padding(14.dp))
    }
}

@Composable
private fun TasksPane(
    tasks: List<JarvisTask>,
    onAdd: (String) -> Unit,
    onToggle: (JarvisTask, Boolean) -> Unit,
    onDelete: (JarvisTask) -> Unit
) {
    var draft by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Vazifalar", color = MainText, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Bu ro‘yxat faqat shu telefonda saqlanadi.", color = MutedText, fontSize = 12.sp)
        Spacer(Modifier.height(14.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = draft,
                onValueChange = { draft = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Yangi vazifa…") },
                singleLine = true
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = { val item = draft.trim(); if (item.isNotEmpty()) { onAdd(item); draft = "" } }, enabled = draft.isNotBlank()) { Text("Qo‘shish") }
        }
        Spacer(Modifier.height(12.dp))
        if (tasks.isEmpty()) {
            EmptyPanel("Hozircha vazifa yo‘q", "Birinchi vazifangizni yuqoridan qo‘shing.")
        } else {
            LazyColumn(modifier = Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(tasks, key = { it.id }) { task ->
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(15.dp)) {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = task.isDone, onCheckedChange = { onToggle(task, it) })
                            Text(task.title, modifier = Modifier.weight(1f), color = if (task.isDone) MutedText else MainText, fontSize = 14.sp)
                            TextButton(onClick = { onDelete(task) }) { Text("O‘chirish", color = MutedText, fontSize = 11.sp) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MemoryPane(
    memories: List<MemoryNote>,
    onAdd: (String) -> Unit,
    onDelete: (MemoryNote) -> Unit
) {
    var draft by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Shaxsiy xotira", color = MainText, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Faqat o‘zingiz qo‘shgan ma’lumotlar Claude kontekstiga yuboriladi.", color = MutedText, fontSize = 12.sp, lineHeight = 18.sp)
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(
            value = draft,
            onValueChange = { draft = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Masalan: Men ertalab o‘qishni afzal ko‘raman…") },
            minLines = 2,
            maxLines = 4
        )
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = { val note = draft.trim(); if (note.isNotEmpty()) { onAdd(note); draft = "" } },
            enabled = draft.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) { Text("Xotiraga saqlash") }
        Spacer(Modifier.height(13.dp))
        if (memories.isEmpty()) {
            EmptyPanel("Xotira hali bo‘sh", "JARVIS bilishi kerak bo‘lgan, maxfiy bo‘lmagan foydali ma’lumotlarni qo‘shing.")
        } else {
            LazyColumn(modifier = Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(memories, key = { it.id }) { note ->
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
                        Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(note.content, color = MainText, fontSize = 13.sp, lineHeight = 19.sp, modifier = Modifier.weight(1f))
                            TextButton(onClick = { onDelete(note) }) { Text("×", color = MutedText, fontSize = 22.sp) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsPane(
    vault: SecretVault,
    saved: Boolean,
    currentModel: String,
    voiceReplyEnabled: Boolean,
    onSaveKey: (String) -> Unit,
    onDeleteKey: () -> Unit,
    onModelChange: (String) -> Unit,
    onVoiceReplyChange: (Boolean) -> Unit
) {
    var apiKey by remember { mutableStateOf(vault.readApiKey().orEmpty()) }
    var model by remember { mutableStateOf(currentModel) }
    var revealKey by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Sozlamalar", color = MainText, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("AI xizmatiga ulanish va ilova xatti-harakatlari.", color = MutedText, fontSize = 12.sp)
        Spacer(Modifier.height(16.dp))
        SectionCard("ANTHROPIC API") {
            Text("API kalit", color = MainText, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            OutlinedTextField(
                value = apiKey,
                onValueChange = { apiKey = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("sk-ant-…") },
                singleLine = true,
                visualTransformation = if (revealKey) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { revealKey = !revealKey }) { Text(if (revealKey) "Yashirish" else "Ko‘rsatish", color = Accent) }
                Spacer(Modifier.weight(1f))
                Text(if (saved) "Kalit saqlangan" else "Kalit kiritilmagan", color = if (saved) Color(0xFF72DDB1) else MutedText, fontSize = 11.sp)
            }
            Button(onClick = { if (apiKey.isNotBlank()) onSaveKey(apiKey) }, enabled = apiKey.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Kalitni xavfsiz saqlash") }
            if (saved) {
                OutlinedButton(onClick = { onDeleteKey(); apiKey = "" }, modifier = Modifier.fillMaxWidth()) { Text("Kalitni o‘chirish") }
            }
            Text(
                "Eslatma: Claude API alohida hisob va kredit talab qiladi; Claude Pro obunasi API kreditlarini bermaydi. So‘rovlar pulli bo‘lishi mumkin. 18 yoshdan kichik foydalanuvchilar uchun Anthropic API integratsiyasida qo‘shimcha tashkilot xavfsizligi va muvofiqlik talablari bor — ota-ona yoki maktab nazoratisiz hisob ochmang.",
                color = MutedText,
                fontSize = 11.sp,
                lineHeight = 16.sp
            )
        }
        Spacer(Modifier.height(12.dp))
        SectionCard("MODEL") {
            OutlinedTextField(
                value = model,
                onValueChange = { model = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("Model ID") }
            )
            Button(onClick = { onModelChange(model) }, modifier = Modifier.fillMaxWidth()) { Text("Modelni saqlash") }
            Text("Standart: claude-sonnet-5. Model nomi Anthropic hisobingizda mavjud bo‘lishi kerak.", color = MutedText, fontSize = 11.sp, lineHeight = 16.sp)
        }
        Spacer(Modifier.height(12.dp))
        SectionCard("OVOZ") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Javobni ovoz chiqarib o‘qish", color = MainText, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Text("Android TTS ovozidan foydalanadi.", color = MutedText, fontSize = 11.sp)
                }
                Switch(checked = voiceReplyEnabled, onCheckedChange = onVoiceReplyChange)
            }
        }
        Spacer(Modifier.height(14.dp))
        Text("Maxfiylik: xabarlar, vazifalar va xotiralar telefoningizdagi lokal bazada saqlanadi. Chat yuborilganda oxirgi suhbat, saqlangan xotiralar va ochiq vazifalar Anthropic API'ga jo‘natiladi.", color = MutedText, fontSize = 11.sp, lineHeight = 16.sp)
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, color = Accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
            content()
        }
    }
}

@Composable
private fun EmptyPanel(title: String, description: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(Modifier.fillMaxWidth().padding(18.dp)) {
            Text(title, color = MainText, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Spacer(Modifier.height(4.dp))
            Text(description, color = MutedText, fontSize = 12.sp, lineHeight = 18.sp)
        }
    }
}
