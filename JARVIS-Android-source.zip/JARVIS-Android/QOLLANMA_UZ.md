# JARVIS Android — Abdulaziz uchun qo‘llanma

## Hozir nima tayyor?

Bu ZIP ichida Android uchun Kotlin/Jetpack Compose manba loyihasi bor. Bu hali APK emas: joriy ish muhitida Android SDK va Gradle bo‘lmagani uchun APK build qilib, Redmi 15C’da sinab ko‘rishning imkoni bo‘lmadi.

Birinchi versiyada quyidagilar yozilgan:

- JARVIS chat oynasi;
- Claude Messages API bilan suhbat;
- Android mikrofonidan ovozli matn kiritish;
- Android TextToSpeech orqali javobni ovoz chiqarib o‘qish;
- chat tarixini telefonda saqlash;
- vazifalar ro‘yxati;
- foydalanuvchi o‘zi qo‘shadigan shaxsiy xotira;
- API kalitini Android Keystore yordamida shifrlab saqlash.

Telegram bot, fon rejimida doimiy agent, bildirishnoma/eslatmalar va telefonda lokal LLM hali qo‘shilmagan.

## APK'ni kompyutersiz GitHub Actions orqali olish

1. GitHub'da yangi, bo‘sh repository yarating.
2. Ushbu loyiha ZIP'ini telefoningizda ochib (Extract), ichidagi barcha fayl va papkalarni repository'ning asosiy joyiga yuklang. `settings.gradle.kts`, `build.gradle.kts` va `app/` to‘g‘ridan-to‘g‘ri repository root ichida turishi kerak.
3. Repository'dagi `Actions` bo‘limiga kiring. Workflow ruxsatini so‘rasa, yoqing.
4. Chap tomondagi **Build JARVIS APK** workflow'ni tanlang.
5. **Run workflow** tugmasini bosing.
6. Build yashil belgi bilan tugasa, shu run sahifasining pastidagi `jarvis-debug-apk` artifact'ini yuklab oling.
7. Yuklangan artifact ZIP'ini oching. Ichidan `app-debug.apk` faylini toping.
8. APK'ni Redmi 15C'ga o‘tkazing va o‘rnating. Android fayl menejeriga noma'lum manbadan ilova o‘rnatish ruxsatini so‘rashi mumkin.

## Kompyuterda Android Studio bilan

1. ZIP'ni kompyuterda oching.
2. Android Studio → Open → `JARVIS-Android` papkasini tanlang.
3. Android SDK Platform 36 o‘rnatilgan bo‘lsin.
4. Gradle sync tugagach, Build → Build APK(s) ni tanlang.
5. APK odatda `app/build/outputs/apk/debug/app-debug.apk` ichida paydo bo‘ladi.

## Claude ulanishi va yoshga oid muhim qoida

Claude API oddiy Claude Pro obunasidan alohida hisob-kitob qilinadi va so‘rovlar uchun haq olinishi mumkin. API kalitini Anthropic shartlariga muvofiq ruxsat etilgan hisob egasi boshqarishi kerak.

Anthropic'ning iste'molchi Claude xizmati 18 yoshdan kattalar uchun. Voyaga yetmaganlarga xizmat ko‘rsatadigan API ilovalari uchun tashkilot darajasida qo‘shimcha xavfsizlik va muvofiqlik talablari mavjud. Yoshni noto‘g‘ri ko‘rsatib hisob ochmang; zarur bo‘lsa ota-ona/vasiy yoki maktab bilan qonuniy va ruxsat etilgan API ulanishini tashkil qiling.

## Maxfiylik

Chat tarixi, vazifalar va xotira telefon ichida saqlanadi. Claude'ga xabar yuborilganda so‘nggi suhbat xabarlari, saqlangan xotiralar va ochiq vazifalar Anthropic API'ga yuboriladi. Xotiraga parol, karta raqami, SMS tasdiqlash kodi yoki boshqa maxfiy ma'lumot kiritmang.
