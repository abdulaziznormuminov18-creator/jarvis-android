# Notice

This Android app is a separate native implementation. It does not package or copy the OpenJarvis Python/Rust runtime or source files. Its product direction and architecture are informed by the public OpenJarvis project: https://github.com/open-jarvis/OpenJarvis.

The upstream OpenJarvis project identifies its license as Apache-2.0. Refer to the upstream repository for its license and notices.
